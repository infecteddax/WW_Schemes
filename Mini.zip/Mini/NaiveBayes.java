import java.sql.*;
import java.util.*;

class NaiveBayes
{
    public static void main(String args[])
    {
		try
		{
			/*
			c1 and c2 denote class 1 & class 2. 
			class1 :- scheme buys computer
			class2 :- scheme doesn't buy computer
			*/
			Class.forName("com.mysql.jdbc.Driver");  
                                                Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/women","root","root");
			Statement s = con.createStatement();
			String query = null;
			ResultSet rs = null;
			int c1=0 ,c2=0 ,n=0;

			query ="SELECT     COUNT(*) AS Expr1    FROM   scheme WHERE (Sanction_Scheme = 'yes') ";
			s.execute(query);
			rs= s.getResultSet();
			if(rs.next())
					//Count of cases when computer was bought n training set
					c1=Integer.parseInt(rs.getString(1));

			query ="SELECT     COUNT(*) AS Expr1    FROM   scheme WHERE (Sanction_Scheme = 'no') ";
			s.execute(query);
			rs= s.getResultSet();
			if(rs.next())
					//Count of cases when computer was not bought in training set
					c2=Integer.parseInt(rs.getString(1)); 

			query = "SELECT     COUNT(*) AS Expr1   FROM  scheme ";
			s.execute(query);
			rs= s.getResultSet();
			if(rs.next())
					//Count of total cases in training set
					n = Integer.parseInt(rs.getString(1)); 

			float pc1 = (float)c1/n; //General probability for class c1
			float pc2 = (float)c2/n; //General probability for class c2

			System.out.println("c1= " +c1 +"\nc2="+c2+"\ntotal="+n);
			System.out.println("p(c1)="+pc1);
			System.out.println("p(c2)="+pc2);

			Scanner sc = new Scanner(System.in);

			String Age,Income,Occupation,Sanction,class1;
			
			// Accept the parameter values for which class is to be predicted
			
			System.out.println("Enter Age: (>20/20-50/>50)");
			Age = sc.next();

			System.out.println("Enter Income:(low/high)");
			Income = sc.next();

			System.out.println("Enter Occupation:(Unemployed/employed/Business)");
			Occupation = sc.next();


			float pinc1=0,pinc2=0;
			//pinc1 = probability of prediction to be class1 (will buy)
			//pinc2 = probability of prediction to be class2  (will not buy)
				
			pinc1 = pfind(Age,Income,Occupation,"yes");
			pinc2 = pfind(Age,Income,Occupation,"no");

			pinc1 = pinc1 * pc1;
			pinc2 = pinc2 * pc2;
			System.out.println(pinc1);
			System.out.println(pinc2);
			// compare pinc1 & pinc2 and predict the class that user will or won't buy
			if(pinc1 < pinc2)
				System.out.println("Scheme will be Sanctioned");
			else
				System.out.println("Scheme will not be Sanctioned");

			s.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println("Exception:"+ e);
		}
	}

	public static float pfind(String Age,String Income,String Occupation,String class1)
	{
		float ans = 0;
		try{
			Scanner sc = new Scanner(System.in);
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/women","root","root");
			Statement s = con.createStatement();
			String query = null;
			ResultSet rs = null;
			int a=0 , b=0 , c=0 , d=0 , total=0;
			
			/* 	Queries below are constructed using parameter values of age , income , student , credit_rating , class
				passed to function. Function finds probability for every individual parameter of provided class value 
				and using naive baye's theorem it calculates total probability */
			

			query ="SELECT    COUNT(*) AS Expr1     FROM   scheme WHERE   (Age = '"+ Age + "' ) AND (Sanction_Scheme = '" +class1 +"') ";
			s.execute(query);
			rs= s.getResultSet();
			if(rs.next())
					a=Integer.parseInt(rs.getString(1));
			// a = count of values in training set having age , class same as passed in argument

			query ="SELECT    COUNT(*) AS Expr1     FROM   scheme WHERE   ( Income = '"+ Income + "' ) AND (Sanction_Scheme= '" +class1 +"') ";
			s.execute(query);
			rs= s.getResultSet();
			if(rs.next())
					b=Integer.parseInt(rs.getString(1));
			// b = count of values in training set having income , class same as passed in argument


			query ="SELECT    COUNT(*) AS Expr1     FROM   scheme WHERE   ( Occupation = '"+ Occupation + "' ) AND (Sanction_Scheme = '" +class1 +"') ";
			s.execute(query);
			rs= s.getResultSet();
			if(rs.next())
					c=Integer.parseInt(rs.getString(1));
			// c = count of values in training set having student , class same as passed in argument



			query ="SELECT    COUNT(*) AS Expr1     FROM   scheme WHERE   (class = '" +class1 +"') ";
			s.execute(query);
			rs= s.getResultSet();
			if(rs.next())
					total=Integer.parseInt(rs.getString(1)); //total no resuults

			ans = (float)a / (float)total  * (float)b /(float)total * (float)c /(float)total ;
			//calculating total probability by naive bayes
			
			s.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println("Exception:"+ e);
		}
 