<?php 
$conn = mysqli_connect("localhost","root", "");

mysqli_select_db($conn,"wws");

if(!$conn)
	echo"error";
else
	echo "";
?>
<html>
<!DOCTYPE html>
<html lang="en" >

<head>
	<style type="text/css">
body
{
	background-color: white;
}		
p.big {
    line-height: 1.1;
	font-family: Arial, Helvetica, sans-serif;
}
#ABC {
  background-color: #48C9B0;
      height: 5%;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
    }
.button {
    border: none;
    color: white;
    padding: 2px 2px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 14px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
	float: right;
}

.button1 {
    background-color: white;
    color: black;
    border: 2px solid #555555;
}

.button1:hover {
    background-color: #555555;
    color: white;
}
</style>
<script type="text/javascript">  
function myFunction() {
			document.getElementById("b").style.fontSize = "1.5em";
		}
		function myFunction1() {
			document.getElementById("b").style.fontSize = "1em";
		}
		function myFunction2() {
			document.getElementById("b").style.fontSize = "0.5em";
		}
    </script>  
</head>

<body id="b">
	<section id="ABC">
		<button onclick="myFunction2()" class="button button1">A-</button> 
		<button onclick="myFunction1()" class="button button1">A</button> 
		<button onclick="myFunction()" class="button button1">A+</button> 
	</section>
	<br><br><br>
	<div class="a" style="text-align:center;">
		<p class="big">
			<font size="10" color="#B9770E"><b>NARI</b><br></font>
			<font size="5" color="#B9770E">NATIONAL REPOSITORY OF INFORMATION OF WOMEN<br></font>
			Ministry of Women and child Development
		</p>
	</div>
	
	<div>
	<p><font size="5" color="#B9770E"><b> Schemes:</b></p></font>
	<hr>
	</div>
	
<table>
	<tr>
		<th> Age_group </th>
		<th> Department </th>
		<th> Scheme_name </th>
	</tr>
	<?php
	$sql="SELECT * FROM schemes;";
	$records=mysqli_query($conn,$sql);
	if($records -> num_rows >0){
		while($my=mysqli_fetch_assoc($records)){
			echo "<tr><td>".$my['age_group']."</td><td>".$my['department']."</td><td>".$my['scheme_name']."</td></tr>";
		}
	}			
$conn->close();
?>
</body>
</html>

